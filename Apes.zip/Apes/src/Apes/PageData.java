package Apes;
import java.util.Hashtable;

public class PageData implements java.io.Serializable {
	
	private String pageName;
	private Hashtable<String,Object> max;
	private Hashtable<String,Object> min;
	private boolean isFull;
	
	public PageData(String pageName, Hashtable<String, Object> max, Hashtable<String, Object> min, boolean isFull) {
		this.pageName = pageName;
		this.max = max;
		this.min = min;
		this.isFull = isFull;
	}

	public Hashtable<String, Object> getMax() {
		return max;
	}

	public String getPageName() {
		return pageName;
	}

	public void setMax(Hashtable<String, Object> max) {
		this.max = max;
	}

	public void setMin(Hashtable<String, Object> min) {
		this.min = min;
	}

	public boolean isFull() {
		return isFull;
	}

	public Hashtable<String, Object> getMin() {
		return min;
	}

	public void setFull(boolean isFull) {
		this.isFull = isFull;
	}
}