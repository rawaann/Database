package Apes;
import java.awt.Polygon;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Random;
import java.util.StringTokenizer;
public class DBAppTest {
	public static void main(String[]args) {	
		DBApp dbApp = new DBApp( );
		dbApp.init();
		String strTableName = "Student";
		// Create table
		Hashtable<String, String> htblColNameType = new Hashtable<String, String>( );
		htblColNameType.put("id", "java.lang.Integer");
		htblColNameType.put("name", "java.lang.String");
		htblColNameType.put("gpa", "java.lang.Double");
		try {
			dbApp.createTable( strTableName, "id", htblColNameType );
		} catch (DBAppException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//insert into table
		for(int i= 0 ; i< 20000 ; i++) {
			Hashtable<String,Object> input = new Hashtable<String, Object>();
			Random r = new Random();
			int n = r.nextInt(20);
			input.put("id", new Integer(n));
			input.put("name",new String ("sam"));
			input.put("gpa", new Double(1.5));
			try {
				dbApp.insertIntoTable("Student",input);
			} catch (DBAppException e) {
				e.printStackTrace();
			}
		}
		//prints table
		dbApp.printTable(strTableName);
		/*for(int i=0 ; i< 5 ; i++) {
			Random r = new Random();
			int n = r.nextInt(5)+5;
			System.out.print(n + "  ");
			Hashtable<String,Object> remove = new Hashtable<String, Object>();
			remove.put("id",new Integer (n));
			try {
				dbApp.deleteFromTable("Student", remove);
			} catch (DBAppException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		dbApp.printTable(strTableName);
		
		createProperties();
	*/	}
	
}

