package Apes;
import java.io.Serializable;
import java.util.Hashtable;
import java.util.Vector;

public class Page extends Vector<Hashtable<String,Object>> implements Serializable {
	private int size;  
	
	public Page(int size) {
		this.size = size;
	}

	public boolean isFull() {
		return (this.size() == size);
	}

	public int getSize() {
		return size;
	}
	
	
}
