package Apes;
import java.awt.Polygon;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;
import java.util.Set;
import java.util.Vector;

public class Table implements java.io.Serializable {
	
	private int pageCounter;
	private String name;
	private String strClusteringKeyColumn;
	private Vector<PageData> pages;

	public Table(String name, String strClusteringKeyColumn) {
		this.pageCounter = 0;
		this.name = name;
		this.strClusteringKeyColumn = strClusteringKeyColumn;
		this.pages = new Vector<PageData>();
	}
	
	public void insert(Hashtable<String,Object> htblColNameValue) throws DBAppException {
		if(!checkValidInsertion(htblColNameValue)) {
			throw new DBAppException("the entered tuple is invalid");
		}
		
		Date date = new Date();
 		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
 		htblColNameValue.put("TouchDate",dateFormat.format(date));
		
		if(pages.isEmpty()) {
			createNewPage(htblColNameValue);
			serialize(this,"data/" +name+".class");
			return;
		}
		
		else {
			for(int i= 0 ; i<pages.size() ; i++) {
				PageData pd = pages.get(i);
				if(!pd.isFull()) {
					if(compareTuples(htblColNameValue.get(strClusteringKeyColumn), pd.getMax().get(strClusteringKeyColumn))) {
						Page p = (Page) deserialize("data/"+pd.getPageName()+".class");
						for(int j = 0 ; j < p.size() ; j++) {
							if(compareTuples(htblColNameValue.get(strClusteringKeyColumn),p.get(j).get(strClusteringKeyColumn))) {
								insertIntoPage(pd, p, htblColNameValue, j);
								serialize(this,"data/" +name+".class");
								return;
							}
						}
					}
					
					else {
						if(pages.size()==(i+1) || 
								compareTuples(htblColNameValue.get(strClusteringKeyColumn), pages.get(i+1).getMin().get(strClusteringKeyColumn))) {
							Page p = (Page) deserialize("data/"+pd.getPageName()+".class");
							insertIntoPage(pd, p, htblColNameValue, p.size());
							serialize(this,"data/" +name+".class");
							return;
						}
					}
				}
				else {
					if(compareTuples(htblColNameValue.get(strClusteringKeyColumn), pd.getMax().get(strClusteringKeyColumn))) {
						Page p = (Page) deserialize("data/"+pd.getPageName()+".class");
						Hashtable<String,Object> oldMax = pd.getMax();
						p.remove(oldMax);
						if (compareTuples(p.lastElement().get(strClusteringKeyColumn),htblColNameValue.get(strClusteringKeyColumn))
								||	ifEquals(p.lastElement().get(strClusteringKeyColumn),htblColNameValue.get(strClusteringKeyColumn))) {
							insertIntoPage(pd, p, htblColNameValue, p.size());
							insert(oldMax);
							serialize(this,"data/" +name+".class");
							return;
						}
						for(int j = 0 ; j<p.size() ; j++) {
							if(compareTuples(htblColNameValue.get(strClusteringKeyColumn),p.get(j).get(strClusteringKeyColumn))) {
								insertIntoPage(pd, p,htblColNameValue,j);
								insert(oldMax);
								serialize(this,"data/" +name+".class");
								return;
							}
						}
					}
					else if(pages.size()==(i+1)) {
						createNewPage(htblColNameValue);
						serialize(this,"data/" +name+".class");
						return;
					}
				}
			}
		}
		serialize(this,"data/" +name+".class");
	}
	
	private void insertIntoPage(PageData pageData, Page page, Hashtable<String,Object> tuple, int index ){
		page.add(index,tuple);
		pageData.setFull(page.isFull());
		pageData.setMax(page.lastElement());
		pageData.setMin(page.lastElement());
		serialize(page,"data/"+pageData.getPageName()+".class");		
	}
	
	private void createNewPage(Hashtable<String,Object> htblColNameValue) {
		
		FileReader reader;
		try {
			reader = new FileReader("config/DBApp.properties");
			Properties p=new Properties();  
		    p.load(reader);    
			Page page = new Page(Integer.parseInt(p.getProperty("MaximumRowsCountinPage")));
			page.add(htblColNameValue);
			PageData pagedata = new PageData(name+"_page"+ pageCounter, htblColNameValue, htblColNameValue, page.isFull());
			pageCounter++;
			pages.add(pagedata);
			String path = "data/"+pagedata.getPageName()+".class";
			serialize(page, path);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	}
	
	public void delete(Hashtable<String,Object> htblColNameValue) throws DBAppException {
		if(!checkValidDeletionUpdate(htblColNameValue)) {
			throw new DBAppException("Deletion : Invalid input");
		}
		for(int i =0 ; i < pages.size() ;i++) {
			PageData pageData = pages.get(i);
			Page page = (Page) deserialize("data/" + pageData.getPageName() + ".class");
		
			for(int j = 0 ; j<page.size() ; j++) {
				Hashtable<String, Object> tuple = page.get(j);
				if (checkDeleteTuple(htblColNameValue, tuple)) {
					page.remove(tuple);
					j--;
					pageData.setFull(page.isFull());
					serialize(page,"data/" + pageData.getPageName() + ".class");
				}
			}
			if (page.isEmpty()) {
				File file = new File("data/" + pageData.getPageName() + ".class");
				file.delete();
				pages.remove(pageData);
				i--;
				serialize(this,"data/" + name + ".class");
			}
			else {
				pageData.setMax(page.lastElement());
				pageData.setMin(page.firstElement());
				serialize(this,"data/" + name + ".class");
			}
		}
		serialize(this,"data/" + name + ".class");
	}
	
	private boolean checkDeleteTuple(Hashtable<String,Object> htblColNameValue , Hashtable<String,Object> tuple) {
		Set<String> keys = htblColNameValue.keySet();
		for(String key : keys) {
			if(!tuple.get(key).equals(htblColNameValue.get(key)))
				return false;
		}
		return true;	
	}
	
	private boolean compareTuples(Object o1, Object o2) {
		if(o1 instanceof Integer && ((int) o1 < (int) o2))
			return true;
		else if(o1 instanceof String && (((String) o1).compareTo((String)o2) > 0))
			return true;
		else if(o1 instanceof Double && ((Double) o1 < (Double) o2))
			return true;
		else if(o1 instanceof Polygon) { 
			MyPolygon polygon = new MyPolygon((Polygon)o1);
			if((polygon.compareTo((Polygon)o2) < 0))
				return true;
		}
		else if(o1 instanceof Date && (((Date) o1).compareTo((Date)o2) < 0))
			return true;
		return false;
	}

	private boolean checkValidInsertion(Hashtable<String,Object> htblColNameValue) {
		  BufferedReader fileReader = null;
			Set<String> keys = htblColNameValue.keySet();
			keys.remove("TouchDate");
	        try {
	            String line = "";
	            fileReader = new BufferedReader(new FileReader("data/metadata.csv"));
	            fileReader.readLine();
	            ArrayList<String []> all_columns = new ArrayList<>();
	            
	            while ((line = fileReader.readLine()) != null) {
	            	String[] column_CSV = line.split(",");
	            	if(column_CSV.length > 0 && column_CSV[0].equals(name))
	            		all_columns.add(column_CSV);
	            }
	            
	            if(keys.size()!=all_columns.size()) {
	            	return false;
	            }
	            
	            for(int i = 0; i<all_columns.size() ; i++) {
	            	String[] column_CSV = (String[]) all_columns.get(i);
	            	String columnName = column_CSV[1];
	            	String columnType = column_CSV[2];
	            	
	            	if (!keys.contains(columnName)) {
	            		return false;
	            	}
	            	
	            	Object columnValue = htblColNameValue.get(columnName);
	            	if(!valid_type(columnType, columnValue))
	            		return false;
	            }
	        } 
	        catch (Exception e) {
	        	System.out.println("Error in CsvFileReader!");
	            e.printStackTrace();
	        } finally {
	            try {
	                fileReader.close();
	            } catch (IOException e) {
	            	System.out.println("Error while closing fileReader");
	                e.printStackTrace();
	            }
	        }

		return true;
	}
	
	private boolean checkValidDeletionUpdate(Hashtable<String,Object> htblColNameValue) {
		BufferedReader fileReader = null;
		Set<String> keys = htblColNameValue.keySet();
		keys.remove("TouchDate");
	        try {
	            String line = "";
	            fileReader = new BufferedReader(new FileReader("data/metadata.csv"));
	            fileReader.readLine();
	            ArrayList<String []> all_columns = new ArrayList<>();
	            
	            while ((line = fileReader.readLine()) != null) {
	            	String[] column_CSV = line.split(",");
	            	if(column_CSV.length > 0 && column_CSV[0].equals(name) && keys.contains(column_CSV[1]))
	            		all_columns.add(column_CSV);
	            }
	            
	            if(keys.size()!=all_columns.size()) {
	            	return false;	
	            }            
	            
	            for(int i = 0; i<all_columns.size() ; i++) {
	            	String[] column_CSV = (String[]) all_columns.get(i);
	            	String columnName = column_CSV[1];
	            	String columnType = column_CSV[2];
	            	Object columnValue = htblColNameValue.get(columnName);
	            	if(!valid_type(columnType, columnValue))
	            		return false;
	            }
	        } 
	        catch (Exception e) {
	        	System.out.println("Error in CsvFileReader!");
	            e.printStackTrace();
	        } finally {
	            try {
	                fileReader.close();
	            } catch (IOException e) {
	            	System.out.println("Error while closing fileReader");
	                e.printStackTrace();
	            }
	        }    
		return true;
	}
	
	private boolean valid_type(String columnType,Object columnValue ) {
		
		if (columnType.contains("String"))
			return (columnValue instanceof String);
		if (columnType.contains("Integer"))
			return (columnValue instanceof Integer);
		if (columnType.contains("Double"))
			return (columnValue instanceof Double);
		if (columnType.contains("Boolean"))
			return (columnValue instanceof Boolean);
		if (columnType.contains("Polygon"))
			return (columnValue instanceof Polygon);
		if (columnType.contains("Date"))
			return (columnValue instanceof Date);
		return false;
	}
		
	public String getName() {
		return name;
	}

	private void serialize(Object object, String path) {
		try {
	         FileOutputStream fileOut = new FileOutputStream(path);
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
	         out.writeObject(object);
	         out.close();
	         fileOut.close();
	      } catch (IOException i) {
	         i.printStackTrace();
	      }
	}
	
	private Object deserialize(String path) {
		Object o = null;
		try {
	         FileInputStream fileIn = new FileInputStream(path);
	         ObjectInputStream in = new ObjectInputStream(fileIn);
	         o = in.readObject();
	         in.close();
	         fileIn.close();
	      } catch (IOException i) {
	         i.printStackTrace();
	      } catch (ClassNotFoundException c) {
	         System.out.println("Table class not found");
	         c.printStackTrace();
	      }
		return o;
	}
	
	public String toString() {
		for(int i = 0 ;i<pages.size() ; i++) {
			Page p = (Page) deserialize("data/" + pages.get(i).getPageName() + ".class");
			for(int j = 0 ; j< p.size() ; j++) {
				System.out.print(p);
			}
			System.out.println();
		}
		return "";
	}
	
	private boolean ifEquals(Object o1, Object o2) {
		if(o1 instanceof Integer && ((int) o1 == (int) o2))
			return true;
		else if(o1 instanceof String && (((String) o1).equals((String)o2)))
			return true;
		else if(o1 instanceof Double && ((Double) o1 == (Double) o2))
			return true;
		else if(o1 instanceof Polygon) { 
			MyPolygon polygon = new MyPolygon((Polygon)o1);
			if((polygon.compareTo((Polygon)o2) == 0))
				return true;
		}
		else if(o1 instanceof Date && (((Date) o1).equals((Date)o2)))
			return true;
		return false;
	}
	
	public void update(Hashtable<String,Object> htblColNameValue,String strClusteringKey) throws DBAppException {
		if(!checkValidDeletionUpdate(htblColNameValue)) {
			throw new DBAppException("the entered tuple is invalid");
		}
		
		Object clusterKeyValue = ClusterKey(clusteringKeyType(), strClusteringKey);
		for (PageData pageData : pages) {
			if (compareTuples(clusterKeyValue , pageData.getMax().get(strClusteringKeyColumn)) 
					|| ifEquals(clusterKeyValue, pageData.getMax().get(strClusteringKeyColumn))) {
				Page page = (Page) deserialize("data/" + pageData.getPageName() + ".class");
				int index = binarySearch(page, clusterKeyValue);
				if (index == -1)
					continue;
				updateToLeft(page, index, clusterKeyValue, htblColNameValue);
				updateToRight(page, index, clusterKeyValue, htblColNameValue);
				serialize(page,"data/" + pageData.getPageName() + ".class");
			}
		}
		serialize(this,"data/" + name + ".class");
	}
	
	private void updateToRight(Page page ,int index , Object clusterKeyValue ,Hashtable<String,Object> htblColNameValue) {
		int i = index + 1;
		do {
			updateTuple(page.get(i),htblColNameValue);
			i++;
		}
		while(i<page.size() && ifEquals(page.get(i).get(strClusteringKeyColumn), clusterKeyValue)); 

	}
	
	private void updateToLeft(Page page ,int index , Object clusterKeyValue ,Hashtable<String,Object> htblColNameValue ) {
		int i = index;
		while(i>=0  && ifEquals(page.get(i).get(strClusteringKeyColumn), clusterKeyValue)) {
			updateTuple(page.get(i),htblColNameValue);
			i--;
		}
	
	}
	
	private void updateTuple(Hashtable<String,Object> tuple ,Hashtable<String,Object> updateColumn ) {
		Date date = new Date();
 		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
 		updateColumn.put("TouchDate",dateFormat.format(date));
		Enumeration<String> e = updateColumn.keys();
		while(e.hasMoreElements()) {
			String columnName = (String) e.nextElement();
			Object newValue  = updateColumn.get(columnName);
			tuple.replace(columnName, newValue);
		}
	}
	
	private int binarySearch(Page page, Object keyvalue) 
    { 
        int l = 0; 
        int r = page.size() - 1; 
        while (l <= r) { 
            int mid_index = l + (r - l) / 2; 
            Hashtable<String,Object> mid = page.get(mid_index);
            Object mid_value = mid.get(strClusteringKeyColumn);
             
            if (ifEquals(mid_value, keyvalue)) 
                return mid_index;  
            // If x greater, ignore left half 
            if (compareTuples(mid_value, keyvalue)) 
                l = mid_index + 1; 
  
            // If x is smaller, ignore right half 
            else
                r = mid_index - 1; 
        } 
        // if we reach here, then element was not present 
        return -1; 
    } 
	
	private String clusteringKeyType() {
		BufferedReader fileReader = null;
		try {
            String line = "";
            fileReader = new BufferedReader(new FileReader("data/metadata.csv"));
            fileReader.readLine();
           
            while ((line = fileReader.readLine()) != null) {
            	String[] column_CSV = line.split(",");
            	if (strClusteringKeyColumn.equals(column_CSV[1])) {
            		return column_CSV[2];
            	}
            }
		} 
        catch (Exception e) {
        	System.out.println("Error in CsvFileReader!");
            e.printStackTrace();
        } finally {
            try {
                fileReader.close();
            } catch (IOException e) {
            	System.out.println("Error while closing fileReader");
                e.printStackTrace();
            }
        }
		return "";
	}
	
	private Object ClusterKey(String type , String key) {
		if (type.contains("Integer"))
			return Integer.parseInt(key);
		if (type.contains("Double"))
			return Double.parseDouble(key);
		if (type.contains("Date"))
			try {
				return new SimpleDateFormat("yyyy/MM/dd").parse(key);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		if (type.contains("Polygon")) {
			MyPolygon myPolygon= new MyPolygon(key); 
			return myPolygon.getPolygon();
		}
		return key;					
	}
}
