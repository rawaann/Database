package Apes;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

public class DBApp {
	
	   private static final String FILE_HEADER = "Table Name,Column Name,Column Type,ClusteringKey,Indexed";
	
	public void init( ) {
		Properties p=new Properties();  
		p.setProperty("MaximumRowsCountinPage","200");  
		p.setProperty("NodeSize","15");  
		  
		try {
			p.store(new FileWriter("config/DBApp.properties"),"DataBase Properties");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void createTable(String strTableName, String strClusteringKeyColumn, Hashtable<String,String> htblColNameType )	
				throws DBAppException {
		
		File file = new File("data/metadata.csv");
		
		//checks if the metadata exists. If it does not exist, then create a new metadata csv file.
		if(!file.exists())
			createCSV(file);
		
		//throws an exception if table already exists.
		if(tableExists(strTableName)) {
			throw new DBAppException("Table already exists");
		}
		
		//creates a new table and adds it to the metadata.
		Table table = new Table(strTableName, strClusteringKeyColumn);
		addToCSV(table , strClusteringKeyColumn, htblColNameType);
		
		//serialize the table.
		try {
	         FileOutputStream fileOut = new FileOutputStream("data/" + strTableName + ".class");
	         ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(table);
	         out.close();
	         fileOut.close();
	      } catch (IOException i) {
	         i.printStackTrace();
	      }
	}
	
	//creates the Metadata with a file_Header --> case : when metadata does not exist.
	private void createCSV(File file) {
		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter(file,true);	          
			fileWriter.append(FILE_HEADER.toString());
			fileWriter.append("\n");
		}catch (Exception e) {
			System.out.println("Error in CsvFileWriter");
	        e.printStackTrace();
		} finally {
			try {
				fileWriter.flush();
	            fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter");
				e.printStackTrace();
	        	}
		}
	}
	
	//Adds a Table to the metadata.CSV.
	private void addToCSV(Table table , String strClusteringKey,Hashtable<String,String> htHashtable) {
		String name = table.getName();
		Enumeration<String> columns = htHashtable.keys();
		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter("data/metadata.csv",true);
			
			while (columns.hasMoreElements()) {
				fileWriter.append(name);
				fileWriter.append(",");
				String columnName = (String) columns.nextElement();
				fileWriter.append(columnName);
				fileWriter.append(",");
				fileWriter.append(htHashtable.get(columnName));
				fileWriter.append(",");
				
				if(columnName.equals(strClusteringKey))
					fileWriter.append("True");
				else
					fileWriter.append("False");
				
				fileWriter.append(",");
				fileWriter.append("False");
				fileWriter.append("\n");	
			}
			
		}catch (Exception e) {
			System.out.println("Error in CsvFileWriter");
	        e.printStackTrace();
		} finally {
			try {
				fileWriter.flush();
	            fileWriter.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter");
				e.printStackTrace();
	        	}
		}
	}
	
	//Checks if the table already exists in the Metadata.
	private boolean tableExists(String tableName) {
		BufferedReader fileReader = null;
	    Boolean out = false; 
        try {
            String line = "";
            fileReader = new BufferedReader(new FileReader("data/metadata.csv"));
            fileReader.readLine();
            while ((line = fileReader.readLine()) != null) {
                String[] tokens = line.split(",");
                if (tokens.length > 0 && tokens[0].equals(tableName)) {
                	out = true;
                }
            }
        } 
        catch (Exception e) {
        	System.out.println("Error in CsvFileReader!");
            e.printStackTrace();
        } finally {
            try {
                fileReader.close();
            } catch (IOException e) {
            	System.out.println("Error while closing fileReader");
                e.printStackTrace();
            }
        }
		return out;
	}
	
	public void createBTreeIndex(String strTableName, String strColName) throws DBAppException{
		
	}
	
	public void createRTreeIndex(String strTableName,String strColName) throws DBAppException{
		// following method inserts one row at a time
	}
	
	public void insertIntoTable(String strTableName, Hashtable<String, Object> htblColNameValue) throws DBAppException{
		Table table = (Table) deserialize("data/" +strTableName + ".class"); 
		table.insert(htblColNameValue); 
	}
		
	public void updateTable(String strTableName, String strClusteringKey, Hashtable<String,Object> htblColNameValue )
	throws DBAppException{
		Table table = (Table) deserialize("data/" +strTableName + ".class");
		table.update(htblColNameValue,strClusteringKey);
	}
	
	public void deleteFromTable(String strTableName, Hashtable<String,Object> htblColNameValue) throws DBAppException {
		Table table = (Table) deserialize("data/" +strTableName + ".class");
		table.delete(htblColNameValue);
		//table.toString();
	}

	private static Object deserialize(String path) {
		Object object = null;
	      try {
	         FileInputStream fileIn = new FileInputStream(path);
	         ObjectInputStream in = new ObjectInputStream(fileIn);
	         object = in.readObject();
	         in.close();
	         fileIn.close();
	      } catch (IOException i) {
	         i.printStackTrace();
	      } catch (ClassNotFoundException c) {
	         System.out.println("Table class not found");
	         c.printStackTrace();
	      }
	    return object;
	}
	
	public void printTable(String tableName) {
		Table table = (Table) deserialize("data/" + tableName + ".class");
		table.toString();
	}
	
	/*public Iterator selectFromTable(SQLTerm[] arrSQLTerms, String[] strarrOperators) throws DBAppException {
	
	}*/

}
